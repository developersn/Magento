<?php

class ModuleBank_Sn_Block_Success extends Mage_Core_Block_Template
{
    protected function _toHtml()
    {
        
        $successUrl = Mage::getUrl('*/*/success', array('_secure'=>true));

        $html	= '<html>'
        		. '<meta http-equiv="refresh" content="0; URL='.$successUrl.'">'
        		. '<body>'
        		. '<p>' . $this->__('با تشکر از پرداخت شما.') . '</p>'
        		. '<p>' . $this->__('اگر به صورت خودکار به صفحه اصلی منتقل نشدید بر روی  <a href="%s">این لینک</a> کلیک کنید', $successUrl) . '</p>'
        		. '</body></html>';

        return $html;
        
    }
}