<?php

class ModuleBank_Sn_Block_Redirect extends Mage_Core_Block_Template
{
    protected function _getCheckout()
    {
        return Mage::getSingleton('checkout/session');
    }
    protected function _getOrder()
    {
        if ($this->getOrder()) {
            return $this->getOrder();
        } elseif ($orderIncrementId = $this->_getCheckout()->getLastRealOrderId()) {
            return Mage::getModel('sales/order')->loadByIncrementId($orderIncrementId);
        } else {
            return null;
        }
    }
    
	public function getFormData()
            	{
            		$order = $this->_getOrder()->_data;
            		$array = $this->_getOrder()->getPayment()->getMethodInstance()->getFormFields();
            		$price = $array["price"];
            		$price = round($order["grand_total"],0);
            		$callBackUrl = Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_LINK);
            		$callBackUrl .= "sn/processing/response/?oID=".$order["entity_id"];
            		date_default_timezone_set("Asia/Tehran");
            		$pin = $this->_getOrder()->getPayment()->getMethodInstance()->getConfigData('seller_id');
            		$ResNum = time();
            		$price = intval($price * 1);

		
					 $data_string = json_encode(array(
					'pin'=> $pin,
					'price'=>  $price,
					'callback'=> $callBackUrl ,
					'order_id'=> $ResNum,
					'description'=> "magento",
					'ip'=> $_SERVER['REMOTE_ADDR'],
					'callback_type'=>2
					));
					    

					$ch = curl_init('https://developerapi.net/api/v1/request');
					curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
					curl_setopt($ch, CURLOPT_HTTPHEADER, array(
					'Content-Type: application/json',
					'Content-Length: ' . strlen($data_string))
					);
					curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
					curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
					$result = curl_exec($ch);
					curl_close($ch);
					$json = json_decode($result,true);
	
		if (!empty($json['result']) AND $json['result'] == 1)
		{
			@session_start();
			$_SESSION['au'] = $json['au'];
			$_SESSION['price'] = $price;
			$_SESSION['ResNum'] = $ResNum;
			
			echo "<div style='display:none'>{$json['form']}</div>Please wait ... <script language='javascript'>document.payment.submit(); </script>";
			
		}
		else
		{
			return 'Error ('.$res.') in RequestPayment...';
		}
	}
}

