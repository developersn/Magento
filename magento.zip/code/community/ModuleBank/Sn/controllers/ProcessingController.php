<?php

class ModuleBank_Sn_ProcessingController extends Mage_Core_Controller_Front_Action
{
    protected $_successBlockType  = 'sn/success';
    protected $_failureBlockType  = 'sn/failure';
    protected $_order = NULL;
    protected $_paymentInst = NULL;

    protected function _getCheckout()
    {
        return Mage::getSingleton('checkout/session');
    }
	public function mkzero($z){
		$str = "1";
		while($z > 0){
			$str .= "0";
			$z -= 1;
		}
		return $str;	
	} 
    public function redirectAction()
    {
        try {
            $session = $this->_getCheckout();

            $order = Mage::getModel('sales/order');
            $order->loadByIncrementId($session->getLastRealOrderId());
            if (!$order->getId()) {
                Mage::throwException('No order for processing found');
            }
            if ($order->getState() != Mage_Sales_Model_Order::STATE_PENDING_PAYMENT) {
                $order->setState(
                    Mage_Sales_Model_Order::STATE_PENDING_PAYMENT,
                    $this->_getPendingPaymentStatus(),
                    Mage::helper('sn')->__('Customer was redirected to sn gateway.')
                )->save();
            }

            if ($session->getQuoteId() && $session->getLastSuccessQuoteId()) {
                $session->setClickandbuyQuoteId($session->getQuoteId());
                $session->setClickandbuySuccessQuoteId($session->getLastSuccessQuoteId());
                $session->setClickandbuyRealOrderId($session->getLastRealOrderId());
                $session->getQuote()->setIsActive(false)->save();
                $session->clear();
            }

            $this->loadLayout();
            $this->renderLayout();
            return;
        } catch (Mage_Core_Exception $e) {
            $this->_getCheckout()->addError($e->getMessage());
        } catch(Exception $e) {
            Mage::logException($e);
        }
		
		
        //$this->_redirect('checkout/cart');
    }
	public function responseAction()
	{
		$session = $this->_getCheckout();
		
		$orderid = $session->getLastRealOrderId();
		$this->_order = Mage::getModel('sales/order')->loadByIncrementId($orderid);
		$this->_paymentInst = $this->_order->getPayment()->getMethodInstance();
		$pin = $this->_paymentInst->getConfigData('seller_id');


		                        	$bank_return = $_POST + $_GET ;
									$data_string = json_encode(array (
									'pin' => $pin,
									'price' =>$_SESSION['price'],
									'order_id' =>	$_SESSION['ResNum'],
									'au' => $_SESSION['au'],
									'bank_return' =>$bank_return,
									));

									$ch = curl_init('https://developerapi.net/api/v1/verify');
									curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
									curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
									curl_setopt($ch, CURLOPT_HTTPHEADER, array(
									'Content-Type: application/json',
									'Content-Length: ' . strlen($data_string))
									);
									curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
									curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
									$result = curl_exec($ch);
									curl_close($ch);
									$json = json_decode($result,true);

		if( ! empty($json['result']) and $json['result'] == 1)
		{
		    
		    
			$this->_order->getPayment()->setTransactionId($_SESSION['au']);
			$this->_order->getPayment()->setLastTransId($_SESSION['au']);
			// create invoice
			if ($this->_order->canInvoice())
			{
			    
				$invoice = $this->_order->prepareInvoice();
				$invoice->register()->capture();
				Mage::getModel('core/resource_transaction')
					->addObject($invoice)
					->addObject($invoice->getOrder())
					->save();
					
			}
		
			$this->_order->addStatusToHistory($this->_paymentInst->getConfigData('order_status'), Mage::helper('sn')->__('Payment complete'));
			// send email
			$this->_order->sendNewOrderEmail();
			$this->_order->setEmailSent(true);	
			$this->_order->save();
			// redirect to success page
			$this->getResponse()->setBody(
			$this->getLayout()
					->createBlock($this->_successBlockType)
					->setOrder($this->_order)
					->toHtml());
			$_SESSION['au'] = $_SESSION['price'] = $_SESSION['ResNum'] = '';
			unset($_SESSION['au']);
		    unset($_SESSION['price'] );
		    unset($_SESSION['ResNum']);
		    
		}
		else
		{
	      	$_SESSION['au'] = $_SESSION['price'] = $_SESSION['ResNum'] = '';
			unset($_SESSION['au']);
		    unset($_SESSION['price'] );
		    unset($_SESSION['ResNum']);
			$this->_redirect('sn/processing/caberror');
		}
	}

    public function successAction()
    {
        try {
            $session = $this->_getCheckout();
            $session->unsClickandbuyRealOrderId();
            $session->setQuoteId($session->getClickandbuyQuoteId(true));
            $session->setLastSuccessQuoteId($session->getClickandbuySuccessQuoteId(true));
            $this->_redirect('checkout/onepage/success');
            return;
        } catch (Mage_Core_Exception $e) {
            $this->_getCheckout()->addError($e->getMessage());
        } catch(Exception $e) {
            Mage::logException($e);
        }
        $this->_redirect('checkout/cart');
    }

    public function caberrorAction()
    {
        // set quote to active
        $session = $this->_getCheckout();
        if ($quoteId = $session->getClickandbuyQuoteId()) {
            $quote = Mage::getModel('sales/quote')->load($quoteId);
            if ($quote->getId()) {
                $quote->setIsActive(true)->save();
                $session->setQuoteId($quoteId);
            }
        }

        $this->getResponse()->setBody(
            $this->getLayout()
                ->createBlock($this->_failureBlockType)
                ->setOrder($this->_order)
                ->toHtml()
        );
    }

	public function cabsuccessAction()
	{
		$this->caberrorAction();
	}

    protected function _checkReturnedParams()
    {
        // get request variables
        $externalBDRID = $this->getRequest()->getParam('externalBDRID');
        $request = $this->getRequest()->getServer();



        // check order id
		list($orderId) = explode('-', $externalBDRID, 2);
        if (empty($orderId) || strlen($orderId) > 50)
            throw new Exception('Missing or invalid order ID', 30);

        // load order for further validation
        $this->_order = Mage::getModel('sales/order')->loadByIncrementId($orderId);
		if (!$this->_order->getId())
			throw new Exception('Order ID not found.', 35);

        // check transaction amount and currency
		if ($this->_order->getPayment()->getMethodInstance()->getConfigData('use_store_currency')) {
        	$price      = number_format($this->_order->getGrandTotal()*100,0,'.','');
        	$currency   = $this->_order->getOrderCurrencyCode();
    	} else {
        	$price      = number_format($this->_order->getBaseGrandTotal()*100,0,'.','');
        	$currency   = $this->_order->getBaseCurrencyCode();
    	}



        return $externalBDRID;
    }

    protected function _getPendingPaymentStatus()
    {
        
        return Mage::helper('sn')->getPendingPaymentStatus();
    }
}
